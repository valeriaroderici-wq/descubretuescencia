javascript
document.addEventListener("DOMContentLoaded", function () {

    const fecha = document.getElementById("fecha");
    const progreso = document.getElementById("progreso");
    const valorProgreso = document.getElementById("valorProgreso");
    const barraProgreso = document.getElementById("barraProgreso");
    const textoProgreso = document.getElementById("textoProgreso");
    const formulario = document.getElementById("formEvolucion");
    const listaRegistros = document.getElementById("listaRegistros");
    const campoFoto = document.getElementById("foto");

    // Establecer fecha de hoy
    if (fecha) {
        fecha.value = new Date().toISOString().split("T")[0];
    }

    // Actualizar la barra mientras se mueve el control
    if (progreso) {
        progreso.addEventListener("input", function () {
            actualizarProgreso(progreso.value);
        });
    }

    function actualizarProgreso(valor) {
        if (!barraProgreso) return;

        barraProgreso.style.width = valor + "%";
        barraProgreso.setAttribute("aria-valuenow", valor);

        if (valorProgreso) {
            valorProgreso.textContent = valor;
        }

        if (textoProgreso) {
            textoProgreso.textContent = valor + "% registrado";
        }
    }

    // Recuperar registros guardados en este navegador
    function obtenerRegistros() {
        try {
            return JSON.parse(localStorage.getItem("kaizenRegistros")) || [];
        } catch (error) {
            return [];
        }
    }

    // Mostrar registros anteriores
    function mostrarRegistros() {
        if (!listaRegistros) return;

        const registros = obtenerRegistros();
        listaRegistros.innerHTML = "";

        if (registros.length === 0) {
            listaRegistros.innerHTML =
                '<p class="text-muted">Tus registros aparecerán aquí.</p>';
            return;
        }

        registros.slice().reverse().forEach(function (registro) {

            const tarjeta = document.createElement("article");
            tarjeta.className = "recurso mb-3";

            const titulo = document.createElement("h3");
            titulo.textContent = registro.actividad;

            const fechaTexto = document.createElement("p");
            fechaTexto.textContent = registro.fecha;

            const comentario = document.createElement("p");
            comentario.textContent = registro.comentario;

            const porcentaje = document.createElement("strong");
            porcentaje.textContent = "Progreso: " + registro.progreso + "%";

            tarjeta.appendChild(titulo);
            tarjeta.appendChild(fechaTexto);
            tarjeta.appendChild(comentario);
            tarjeta.appendChild(porcentaje);

            if (registro.foto) {
                const imagen = document.createElement("img");
                imagen.src = registro.foto;
                imagen.alt = "Fotografía del registro personal";
                imagen.className = "foto-evolucion";
                tarjeta.appendChild(imagen);
            }

            listaRegistros.appendChild(tarjeta);
        });
    }

    // Guardar un nuevo registro
    if (formulario) {
        formulario.addEventListener("submit", async function (evento) {
            evento.preventDefault();

            const actividad = document.getElementById("actividad").value;
            const comentario = document.getElementById("comentario").value.trim();
            const valor = Number(progreso.value);

            let fotoBase64 = "";

            // Comprimir la imagen antes de guardarla para reducir su tamaño
            if (campoFoto.files && campoFoto.files[0]) {
                try {
                    fotoBase64 = await comprimirImagen(campoFoto.files[0]);
                } catch (error) {
                    alert("No se pudo procesar la imagen. Intenta con otra fotografía.");
                    return;
                }
            }

            const registros = obtenerRegistros();

            registros.push({
                fecha: fecha.value,
                actividad: actividad,
                comentario: comentario,
                progreso: valor,
                foto: fotoBase64
            });

            try {
                localStorage.setItem("kaizenRegistros", JSON.stringify(registros));
            } catch (error) {
                alert("El almacenamiento está lleno. Prueba con una fotografía más pequeña.");
                return;
            }

            actualizarProgreso(valor);
            mostrarRegistros();

            formulario.reset();
            fecha.value = new Date().toISOString().split("T")[0];
            progreso.value = 50;
            actualizarProgreso(50);

            alert("¡Tu registro se guardó correctamente!");
        });
    }

    // Redimensionar imágenes grandes antes de guardarlas
    function comprimirImagen(archivo) {
        return new Promise(function (resolve, reject) {

            const lector = new FileReader();

            lector.onload = function (evento) {
                const imagen = new Image();

                imagen.onload = function () {
                    const maximo = 800;
                    let ancho = imagen.width;
                    let alto = imagen.height;

                    if (ancho > alto && ancho > maximo) {
                        alto = Math.round(alto * maximo / ancho);
                        ancho = maximo;
                    } else if (alto >= ancho && alto > maximo) {
                        ancho = Math.round(ancho * maximo / alto);
                        alto = maximo;
                    }

                    const lienzo = document.createElement("canvas");
                    lienzo.width = ancho;
                    lienzo.height = alto;

                    const contexto = lienzo.getContext("2d");
                    contexto.drawImage(imagen, 0, 0, ancho, alto);

                    resolve(lienzo.toDataURL("image/jpeg", 0.7));
                };

                imagen.onerror = reject;
                imagen.src = evento.target.result;
            };

            lector.onerror = reject;
            lector.readAsDataURL(archivo);
        });
    }

    actualizarProgreso(progreso ? progreso.value : 50);
    mostrarRegistros();

});
